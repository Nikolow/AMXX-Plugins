<?php
ob_start();
error_reporting(E_ERROR | E_WARNING | E_PARSE);
ini_set("display_errors", 1);
set_time_limit(10);

// database connection
$dbc = mysql_connect("localhost", "mysql_user", "mysql_password");
if (!$dbc) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db("database_name");

$sql="SELECT * FROM skillpoints_v1 ORDER BY skillpoints DESC LIMIT 30";
$db=mysql_query($sql);
while($b=mysql_fetch_array($db, MYSQL_ASSOC)) {		
	$players[]=$b;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SkillPoints</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<table id="mytable" cellspacing="0">
     <tr>
        <th scope="col" abbr="POSI��O">POSITION</th>
        <th scope="col" abbr="NICK">NICK</th>
        <th scope="col" abbr="STEAM ID">STEAM ID</th>
            <th scope="col" abbr="SKILLPOINTS">SKILLPOINTS</th>
    </tr>
    <?php $i=0;foreach($players as $player){$i++;?>
    <tr>
        <th scope="row" class="spec<?php print ($i%2==0?'alt':'')?>"><?php print $i?></th>
        <td><?php print $player["nick"]?></td>
        <td><?php print $player["authid"]?></td>
        <td><?php print $player["skillpoints"]?></td>
    </tr>
    <?php }?>
</table>
</body>
</html>